/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;
import java.util.Date;

/**
 *
 * @author Alexis
 */
public class ViewModelEmpleado {

     //ATRIBUTOS
    private int ID_Aviones;
    private String modelo;
    private int capacidad;
    private String Tipo;
    /**
     * @return the ID_Aviones
     */
    public int getID_Aviones() {
        return ID_Aviones;
    }

    /**
     * @param ID_Aviones the ID_Aviones to set
     */
    public void setID_Aviones(int ID_Aviones) {
        this.ID_Aviones = ID_Aviones;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the capacidad
     */
    public int getCapacidad() {
        return capacidad;
    }

    /**
     * @param capacidad the capacidad to set
     */
    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    /**
     * @return the Tipo
     */
    public String getTipo() {
        return Tipo;
    }

    /**
     * @param Tipo the Tipo to set
     */
    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

     
   
    
}